<?php

global $_MODULE;

$_MODULE = [];

$_MODULE['<{ps_wellcome_message}prestashop>ps_wellcome_message_3f54f45a329e3b12e7b8bd3aef35d0a5'] = ' Buenos dias!';

$_MODULE['<{ps_wellcome_message}prestashop>ps_wellcome_message_ba27f5879d43e141c4e8b2e3b4ac601c'] = ' Buenas tardes!';

$_MODULE['<{ps_wellcome_message}prestashop>ps_wellcome_message_0763e0e2fae992e6f89f554b5b72d13d'] = ' Buenas noches!';
